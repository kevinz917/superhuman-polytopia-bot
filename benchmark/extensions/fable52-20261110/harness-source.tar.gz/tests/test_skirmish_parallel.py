"""Process isolation must preserve every scheduled result and propagate failures."""
import pytest
from polytopia_bot.skirmish.local_eval import evaluate


def payload(root):
    jobs = [dict(index=i, output_relative=f'games/{i:06d}', job_sha256=str(i),
        candidate=dict(label='candidate', model_label='test', track='continuous', replicate=1,
                       submission_quality='compile_failure'), opponent=dict(label='reference'),
        invalid_submission=True, seat=1+i%2, seed=i, map_type='drylands', phase='heldout')
        for i in (9, 2, 7, 1, 5, 3)]
    return dict(jobs=jobs, references=[], results_root=str(root))


def test_parallel_matches_serial_and_keeps_plan_order(tmp_path):
    serial = evaluate(payload(tmp_path/'serial'))
    parallel = evaluate(dict(payload(tmp_path/'parallel'), workers=3))
    assert parallel == serial
    assert [r['job_index'] for r in parallel] == [9, 2, 7, 1, 5, 3]
    assert len(list((tmp_path/'parallel').glob('games/*/summary.json'))) == 6


def test_parallel_worker_error_is_not_a_model_loss(tmp_path):
    request = payload(tmp_path)
    del request['jobs'][0]['candidate']['label']
    with pytest.raises(KeyError):
        evaluate(dict(request, workers=2))


def test_parallel_rejects_shared_game_output(tmp_path):
    request = payload(tmp_path)
    request['jobs'][1]['output_relative'] = request['jobs'][0]['output_relative']
    with pytest.raises(ValueError, match='distinct'):
        evaluate(dict(request, workers=2))
